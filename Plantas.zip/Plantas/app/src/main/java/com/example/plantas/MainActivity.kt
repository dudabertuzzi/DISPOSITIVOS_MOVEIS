package com.example.plantas
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

data class plantas(val nome: String, val area: String, val data: String)

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: plantasAdapter

    class plantasAdapter(plantasList: Any?) {

    }

    private val plantasList = mutableListOf<Planta>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        adapter = plantasAdapter(plantasList)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewAlunos)
        recyclerView.adapter = plantasAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        val nomeEditText = findViewById<EditText>(R.id.editTextNome)
        val areaEditText = findViewById<EditText>(R.id.editTextArea)
        val addButton = findViewById<Button>(R.id.buttonAdd)
        val zerarButton = findViewById<Button>(R.id.buttonZerar)
        val countTextView = findViewById<TextView>(R.id.textViewCount)

        addButton.setOnClickListener {
            val nome = nomeEditText.text.toString()
            val area = areaEditText.text.toString()
            val dataAtual = SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date())

            if (nome.isNotEmpty() && area.isNotEmpty()) {
                plantasList.add(plantas(nome, area, dataAtual))
                adapter.notifyDataSetChanged()
                countTextView.text = "${plantasList.size}"
            }
        }

        zerarButton.setOnClickListener {
            plantasList.clear()
            adapter.notifyDataSetChanged()
            countTextView.text = "0"
        }
    }
}

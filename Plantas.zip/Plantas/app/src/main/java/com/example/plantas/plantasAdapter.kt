package com.example.alunoapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.alunoapp.AlunoAdapter
import com.example.plantas.R

class AlunoAdapter(private val planta: MutableList<planta>) : RecyclerView.Adapter<plantasAdapter.AlunoViewHolder>() {

    class AlunoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nomeTextView: TextView = itemView.findViewById(R.id.nomeTextView)
        val areaTextView: TextView = itemView.findViewById(R.id.areaTextView)
        val dataTextView: TextView = itemView.findViewById(R.id.dataTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlunoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_plantas, parent, false)
        return AlunoViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlunoViewHolder, position: Int) {
        val aluno = planta[position]
        holder.nomeTextView.text = aluno.nome
        holder.areaTextView.text = aluno.area
        holder.dataTextView.text = aluno.data
    }

    override fun getItemCount(): Int {
        return planta.size
    }
}